data.raw["player"]["player"].inventory_size = 200

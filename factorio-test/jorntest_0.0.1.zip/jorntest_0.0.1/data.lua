data.raw["player"]["player"].inventory_size = 1000
